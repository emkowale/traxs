<?php
/*
 * File: includes/class-traxs-print.php
 * Description: Streams multi-page PDF via FPDF; one page per order.
 */
namespace Traxs;
if (!defined('ABSPATH')) exit;

class Print_WO { public static function stream_batch($order_ids) { /* FPDF build stub */ } }
