<?php
/*
 * File: includes/ajax-traxs.php
 * Description: (Optional) AJAX fallbacks.
 */
namespace Traxs;
if (!defined('ABSPATH')) exit;
