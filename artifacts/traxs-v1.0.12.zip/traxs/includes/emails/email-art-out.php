<?php
/*
 * File: includes/emails/email-art-out.php
 * Description: Email template for email art out.
 * Plugin: Traxs
 * Last Updated: 2025-11-05 21:21:59 EDT
 */
defined('ABSPATH') || exit;
echo '<p>This is the email-art-out email template.</p>';
