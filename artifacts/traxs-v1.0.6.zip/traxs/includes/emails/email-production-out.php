<?php
/*
 * File: includes/emails/email-production-out.php
 * Description: Email template for email production out.
 * Plugin: Traxs
 * Last Updated: 2025-11-05 21:21:59 EDT
 */
defined('ABSPATH') || exit;
echo '<p>This is the email-production-out email template.</p>';
