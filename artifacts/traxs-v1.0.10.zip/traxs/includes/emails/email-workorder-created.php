<?php
/*
 * File: includes/emails/email-workorder-created.php
 * Description: Email template for email workorder created.
 * Plugin: Traxs
 * Last Updated: 2025-11-05 21:21:59 EDT
 */
defined('ABSPATH') || exit;
echo '<p>This is the email-workorder-created email template.</p>';
