<?php
/*
 * File: includes/class-traxs-emails.php
 * Description: Registers per-event email templates and send helpers.
 */
namespace Traxs;
if (!defined('ABSPATH')) exit;

class Emails { public static function send($event, $order_id) { /* enqueue/send via WC */ } }
