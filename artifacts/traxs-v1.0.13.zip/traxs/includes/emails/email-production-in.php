<?php
/*
 * File: includes/emails/email-production-in.php
 * Description: Email template for email production in.
 * Plugin: Traxs
 * Last Updated: 2025-11-05 21:21:59 EDT
 */
defined('ABSPATH') || exit;
echo '<p>This is the email-production-in email template.</p>';
