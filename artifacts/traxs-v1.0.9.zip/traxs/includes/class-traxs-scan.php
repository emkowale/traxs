<?php
/*
 * File: includes/class-traxs-scan.php
 * Description: Scan screen controller; html5-qrcode integration.
 */
namespace Traxs;
if (!defined('ABSPATH')) exit;

class Scan { public static function page() { /* render hooks */ } }
